
from telegram import Update, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, MessageHandler, CommandHandler, ContextTypes, filters
import os
from datetime import timedelta, datetime
from web import keep_alive

# تشغيل Flask
keep_alive()

# متغيرات البيانات
BANNED_WORDS = []
WARNINGS = {}
BANNED_WORDS_FILE = "banned_words.txt"

# متغيرات حماية الرسائل المتكررة (الإسبام)
USER_MESSAGES = {}  # {user_id: [(message_text, timestamp), ...]}
SPAM_WARNINGS = {}  # {user_id: warning_count}

def load_banned_words():
    """تحميل الكلمات الممنوعة من الملف"""
    global BANNED_WORDS
    try:
        with open(BANNED_WORDS_FILE, 'r', encoding='utf-8') as file:
            BANNED_WORDS = [word.strip() for word in file.readlines() if word.strip()]
        print(f"✅ تم تحميل {len(BANNED_WORDS)} كلمة ممنوعة من الملف")
    except FileNotFoundError:
        # إنشاء ملف افتراضي إذا لم يكن موجوداً
        default_words = ["شتيمة", "تخلف", "spam", "t.me/", "http://", "https://"]
        save_banned_words(default_words)
        BANNED_WORDS = default_words
        print("📝 تم إنشاء ملف الكلمات الممنوعة بالقيم الافتراضية")

def save_banned_words(words_list=None):
    """حفظ الكلمات الممنوعة في الملف"""
    words_to_save = words_list if words_list else BANNED_WORDS
    with open(BANNED_WORDS_FILE, 'w', encoding='utf-8') as file:
        for word in words_to_save:
            file.write(f"{word}\n")

def check_spam(user_id, message_text):
    """فحص الرسائل المتكررة (الإسبام)"""
    current_time = datetime.now()
    
    # تنظيف الرسائل القديمة (أكثر من 10 ثوان)
    if user_id in USER_MESSAGES:
        USER_MESSAGES[user_id] = [
            (msg, timestamp) for msg, timestamp in USER_MESSAGES[user_id]
            if (current_time - timestamp).total_seconds() <= 10
        ]
    else:
        USER_MESSAGES[user_id] = []
    
    # إضافة الرسالة الحالية
    USER_MESSAGES[user_id].append((message_text, current_time))
    
    # فحص الرسائل المتكررة
    same_messages = [
        timestamp for msg, timestamp in USER_MESSAGES[user_id]
        if msg == message_text
    ]
    
    return len(same_messages) >= 3  # 3 رسائل متكررة أو أكثر

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [
            InlineKeyboardButton("➕ أضفني إلى مجموعتك | Add me to your group", url="https://t.me/Isle_1v1bot?startgroup=true")
        ],
        [
            InlineKeyboardButton("📢 القناة | Channel", url="https://t.me/Haneen_bint_Youssef"),
            InlineKeyboardButton("🤖 ذكاء اصطناعي | AI Bot", url="https://t.me/RootExpertBot")
        ],
        [
            InlineKeyboardButton("🌐 اللغة | Language", callback_data="set_language"),
            InlineKeyboardButton("🛠 الدعم | Support", callback_data="support_help")
        ]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)

    welcome_message = (
        "🔰 <b>أهلاً بك في بوت الحماية - Isle Guard Bot</b>\n\n"
        "🛡️ <b>Arabic</b>:\n"
        "أنا مساعدك لحماية المجموعات من السبام، الروابط الضارة، والمحتوى المخالف.\n"
        "استخدم /help لمعرفة الأوامر.\n\n"
        "🛡️ <b>English</b>:\n"
        "I protect your groups from spam, harmful links, and unwanted content.\n"
        "Use /help to see the available commands.\n\n"
        "👇 اختر من الأزرار التالية:"
    )

    await update.message.reply_text(
        welcome_message,
        reply_markup=reply_markup,
        parse_mode="HTML"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command"""
    help_message = (
        "📋 كيف أعمل:\n\n"
        "• أراقب الرسائل وأحذف المحتوى المخالف\n"
        "• أحذف الرسائل المعاد توجيهها من القنوات\n"
        "• أحذر المستخدمين عند المخالفة (3 مرات كحد أقصى)\n"
        "• أكتم المستخدم لمدة 24 ساعة بعد 3 مخالفات\n"
        "• أحذف الروابط والمحتوى المشبوه تلقائياً\n\n"
        "🔧 أوامر الإدارة:\n"
        "• /addban <كلمة> - إضافة كلمة للقائمة الممنوعة\n"
        "• /removeban <كلمة> - حذف كلمة من القائمة\n"
        "• /listban - عرض جميع الكلمات الممنوعة\n"
        "• /warnings @username - عرض عدد تحذيرات المستخدم\n"
        "• /clearwarnings @username - مسح تحذيرات المستخدم\n\n"
        "الهدف: الحفاظ على بيئة آمنة ومحترمة للجميع 🔒"
    )
    await update.message.reply_text(help_message)

async def add_ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """إضافة كلمة جديدة للقائمة الممنوعة"""
    user = update.message.from_user
    chat = update.message.chat
    
    # التحقق من صلاحيات الإدارة
    member = await context.bot.get_chat_member(chat.id, user.id)
    if member.status not in ['administrator', 'creator']:
        await update.message.reply_text("❌ هذا الأمر متاح للمديرين فقط!")
        return
    
    if not context.args:
        # تفعيل وضع إضافة الكلمات الممنوعة
        context.user_data['adding_banned_words'] = True
        await update.message.reply_text("❌ يرجى كتابة الكلمة المراد إضافتها\nمثال: /addban كلمة_سيئة\n\n🔄 أرسل الآن الكلمات المراد إضافتها (كل كلمة في سطر منفصل):")
        return
    
    word = " ".join(context.args).lower()
    
    if word in BANNED_WORDS:
        await update.message.reply_text(f"⚠️ الكلمة '{word}' موجودة بالفعل في القائمة!")
        return
    
    BANNED_WORDS.append(word)
    save_banned_words()
    await update.message.reply_text(f"✅ تمت إضافة '{word}' للقائمة الممنوعة بنجاح!")

async def remove_ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """حذف كلمة من القائمة الممنوعة"""
    user = update.message.from_user
    chat = update.message.chat
    
    # التحقق من صلاحيات الإدارة
    member = await context.bot.get_chat_member(chat.id, user.id)
    if member.status not in ['administrator', 'creator']:
        await update.message.reply_text("❌ هذا الأمر متاح للمديرين فقط!")
        return
    
    if not context.args:
        await update.message.reply_text("❌ يرجى كتابة الكلمة المراد حذفها\nمثال: /removeban كلمة")
        return
    
    word = " ".join(context.args).lower()
    
    if word not in BANNED_WORDS:
        await update.message.reply_text(f"⚠️ الكلمة '{word}' غير موجودة في القائمة!")
        return
    
    BANNED_WORDS.remove(word)
    save_banned_words()
    await update.message.reply_text(f"✅ تم حذف '{word}' من القائمة الممنوعة بنجاح!")

async def list_ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض جميع الكلمات الممنوعة"""
    user = update.message.from_user
    chat = update.message.chat
    
    # التحقق من صلاحيات الإدارة
    member = await context.bot.get_chat_member(chat.id, user.id)
    if member.status not in ['administrator', 'creator']:
        await update.message.reply_text("❌ هذا الأمر متاح للمديرين فقط!")
        return
    
    if not BANNED_WORDS:
        await update.message.reply_text("📋 القائمة الممنوعة فارغة حالياً!")
        return
    
    banned_list = "\n".join([f"• {word}" for word in BANNED_WORDS])
    message = f"📋 الكلمات الممنوعة ({len(BANNED_WORDS)}):\n\n{banned_list}"
    
    # تقسيم الرسالة إذا كانت طويلة
    if len(message) > 4096:
        parts = [message[i:i+4096] for i in range(0, len(message), 4096)]
        for part in parts:
            await update.message.reply_text(part)
    else:
        await update.message.reply_text(message)

async def warnings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض عدد التحذيرات لمستخدم معين"""
    user = update.message.from_user
    chat = update.message.chat
    
    # التحقق من صلاحيات الإدارة
    member = await context.bot.get_chat_member(chat.id, user.id)
    if member.status not in ['administrator', 'creator']:
        await update.message.reply_text("❌ هذا الأمر متاح للمديرين فقط!")
        return
    
    # التحقق من وجود mention في الرسالة
    if not update.message.entities or not any(entity.type == 'mention' for entity in update.message.entities):
        await update.message.reply_text("❌ يرجى ذكر المستخدم\nمثال: /warnings @username")
        return
    
    # البحث عن المستخدم المذكور
    mentioned_user = None
    for entity in update.message.entities:
        if entity.type == 'mention':
            username = update.message.text[entity.offset:entity.offset + entity.length].replace('@', '')
            try:
                # البحث عن المستخدم في المجموعة
                chat_members = await context.bot.get_chat_administrators(chat.id)
                for admin in chat_members:
                    if admin.user.username == username:
                        mentioned_user = admin.user
                        break
                
                if not mentioned_user:
                    await update.message.reply_text(f"❌ لم يتم العثور على المستخدم @{username}")
                    return
                
            except Exception:
                await update.message.reply_text(f"❌ لم يتم العثور على المستخدم @{username}")
                return
    
    if mentioned_user:
        warning_count = WARNINGS.get(mentioned_user.id, 0)
        username_display = mentioned_user.username or mentioned_user.first_name
        await update.message.reply_text(f"📊 @{username_display} لديه {warning_count} تحذيرات")

async def clear_warnings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مسح تحذيرات مستخدم معين"""
    user = update.message.from_user
    chat = update.message.chat
    
    # التحقق من صلاحيات الإدارة
    member = await context.bot.get_chat_member(chat.id, user.id)
    if member.status not in ['administrator', 'creator']:
        await update.message.reply_text("❌ هذا الأمر متاح للمديرين فقط!")
        return
    
    # التحقق من وجود mention في الرسالة
    if not update.message.entities or not any(entity.type == 'mention' for entity in update.message.entities):
        await update.message.reply_text("❌ يرجى ذكر المستخدم\nمثال: /clearwarnings @username")
        return
    
    # البحث عن المستخدم المذكور
    mentioned_user = None
    for entity in update.message.entities:
        if entity.type == 'mention':
            username = update.message.text[entity.offset:entity.offset + entity.length].replace('@', '')
            try:
                # البحث عن المستخدم في المجموعة
                chat_members = await context.bot.get_chat_administrators(chat.id)
                for admin in chat_members:
                    if admin.user.username == username:
                        mentioned_user = admin.user
                        break
                
                if not mentioned_user:
                    await update.message.reply_text(f"❌ لم يتم العثور على المستخدم @{username}")
                    return
                
            except Exception:
                await update.message.reply_text(f"❌ لم يتم العثور على المستخدم @{username}")
                return
    
    if mentioned_user:
        old_warnings = WARNINGS.get(mentioned_user.id, 0)
        WARNINGS[mentioned_user.id] = 0
        username_display = mentioned_user.username or mentioned_user.first_name
        await update.message.reply_text(f"✅ تم مسح تحذيرات @{username_display} (كان لديه {old_warnings} تحذيرات)")

async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """ترحيب بالأعضاء الجدد في المجموعة"""
    message = update.message
    
    # التأكد من أن هذا في مجموعة وليس محادثة خاصة
    if message.chat.type == 'private':
        return
    
    # التحقق من وجود أعضاء جدد
    if message.new_chat_members:
        for new_member in message.new_chat_members:
            # تجاهل البوتات
            if new_member.is_bot:
                continue
            
            # إنشاء اسم للعرض
            member_name = new_member.first_name
            if new_member.username:
                member_mention = f"[{member_name}](tg://user?id={new_member.id})"
            else:
                member_mention = f"[{member_name}](tg://user?id={new_member.id})"
            
            # رسالة الترحيب
            welcome_text = f"👋 أهلاً وسهلاً يا {member_mention}! نورت الجروب ❤️"
            
            # قواعد المجموعة
            rules_text = (
                "📜 قوانين الجروب:\n"
                "1. الاحترام المتبادل بين الجميع.\n"
                "2. ممنوع السب أو الشتم.\n"
                "3. لا للروابط أو الإعلانات بدون إذن.\n"
                "4. أي تكرار للمخالفة ممكن يؤدي لكتم أو طرد."
            )
            
            try:
                # إرسال رسالة الترحيب
                await context.bot.send_message(
                    chat_id=message.chat_id,
                    text=welcome_text,
                    parse_mode='Markdown'
                )
                
                # إرسال القواعد
                await context.bot.send_message(
                    chat_id=message.chat_id,
                    text=rules_text
                )
                
                print(f"👋 Welcome message sent for new member: {member_name} (ID: {new_member.id})")
                
            except Exception as e:
                print(f"❌ Error sending welcome message: {str(e)}")
                # محاولة إرسال بدون تنسيق Markdown في حالة الفشل
                try:
                    simple_welcome = f"👋 أهلاً وسهلاً يا {member_name}! نورت الجروب ❤️"
                    await context.bot.send_message(
                        chat_id=message.chat_id,
                        text=simple_welcome
                    )
                    await context.bot.send_message(
                        chat_id=message.chat_id,
                        text=rules_text
                    )
                except Exception as e2:
                    print(f"❌ Error sending simple welcome message: {str(e2)}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle regular messages"""
    message = update.message
    user = message.from_user
    chat_id = message.chat_id
    user_id = user.id
    text = (message.text or message.caption or "").lower()
    
    # تخطي المحادثات الخاصة - حماية الإسبام فقط في المجموعات
    if message.chat.type == 'private':
        await message.reply_text("✅ تم استلام رسالتك.")
        return

    # فحص الرسائل المتكررة (الإسبام) - فقط في المجموعات
    if message.text and len(message.text.strip()) > 0:
        is_spam = check_spam(user_id, message.text)
        
        if is_spam:
            await message.delete()
            
            # زيادة عداد تحذيرات الإسبام
            SPAM_WARNINGS[user_id] = SPAM_WARNINGS.get(user_id, 0) + 1
            spam_warning_count = SPAM_WARNINGS[user_id]
            
            print(f"🔥 Spam detected from user {user_id} ({user.username or user.first_name})")
            print(f"📊 Spam warning count: {spam_warning_count}")
            
            if spam_warning_count == 1:
                # أول تحذير للإسبام
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"⚠️ @{user.username or user.first_name} توقف عن إرسال نفس الرسالة بشكل متكرر! هذا تحذير أول."
                )
                print(f"⚠️ First spam warning sent to user {user_id}")
            else:
                # كتم المستخدم لمدة 10 دقائق
                print(f"🚫 Attempting to mute user {user_id} for 10 minutes due to spam...")
                
                try:
                    # التحقق من أن المستخدم ليس مالك أو مدير المجموعة
                    member = await context.bot.get_chat_member(chat_id, user_id)
                    if member.status in ['creator', 'administrator']:
                        print(f"❌ Cannot mute user {user_id} - User is {member.status}")
                        await context.bot.send_message(
                            chat_id=chat_id,
                            text=f"⚠️ لا يمكن كتم @{user.username or user.first_name} لأنه مدير في المجموعة!"
                        )
                        SPAM_WARNINGS[user_id] = 0  # إعادة تعيين العداد
                        return
                    
                    # كتم المستخدم العادي لمدة 10 دقائق
                    await context.bot.restrict_chat_member(
                        chat_id=chat_id,
                        user_id=user_id,
                        permissions=ChatPermissions(can_send_messages=False),
                        until_date=message.date + timedelta(minutes=10)
                    )
                    
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"🚫 @{user.username or user.first_name} تم كتمه 10 دقائق بسبب الإسبام (الرسائل المتكررة)."
                    )
                    
                    print(f"✅ User {user_id} muted successfully for 10 minutes due to spam")
                    SPAM_WARNINGS[user_id] = 0  # إعادة تعيين العداد بعد الكتم
                    
                except Exception as e:
                    print(f"❌ Error muting user {user_id}: {str(e)}")
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"⚠️ حدث خطأ أثناء محاولة كتم @{user.username or user.first_name}"
                    )
            
            return  # توقف عن معالجة الرسالة
    
    # التحقق من وضع إضافة الكلمات الممنوعة
    if context.user_data.get('adding_banned_words', False):
        # التحقق من صلاحيات الإدارة
        member = await context.bot.get_chat_member(chat_id, user_id)
        if member.status in ['administrator', 'creator']:
            # إضافة الكلمات الجديدة
            new_words = [word.strip().lower() for word in text.split('\n') if word.strip()]
            added_words = []
            existing_words = []
            
            for word in new_words:
                if word not in BANNED_WORDS:
                    BANNED_WORDS.append(word)
                    added_words.append(word)
                else:
                    existing_words.append(word)
            
            if added_words:
                save_banned_words()
                response = f"✅ تمت إضافة {len(added_words)} كلمة جديدة:\n• " + "\n• ".join(added_words)
                if existing_words:
                    response += f"\n\n⚠️ الكلمات التالية موجودة بالفعل:\n• " + "\n• ".join(existing_words)
            else:
                response = "⚠️ جميع الكلمات موجودة بالفعل في القائمة!"
            
            await message.reply_text(response)
            
            # إلغاء وضع إضافة الكلمات
            context.user_data['adding_banned_words'] = False
            return
        else:
            # إلغاء الوضع إذا لم يكن المستخدم مديراً
            context.user_data['adding_banned_words'] = False

    # فحص الرسائل المعاد توجيهها من القنوات (أي نوع من المحتوى)
    violation_detected = False
    violation_reason = ""
    
    if message.forward_from_chat and message.forward_from_chat.type == 'channel':
        violation_detected = True
        violation_reason = "إعادة توجيه رسالة من قناة"
        
        # تحديد نوع المحتوى المعاد توجيهه
        content_type = "نص"
        if message.photo:
            content_type = "صورة"
        elif message.video:
            content_type = "فيديو"
        elif message.document:
            content_type = "ملف"
        elif message.audio:
            content_type = "صوت"
        elif message.voice:
            content_type = "رسالة صوتية"
        elif message.sticker:
            content_type = "ملصق"
        elif message.animation:
            content_type = "GIF"
        
        print(f"📢 Forwarded channel message detected from user {user_id} ({user.username or user.first_name})")
        print(f"📢 Channel: {message.forward_from_chat.title or message.forward_from_chat.username}")
        print(f"📢 Content type: {content_type}")
    
    # فحص الكلمات الممنوعة (فقط للرسائل النصية)
    elif message.text and any(word in text for word in BANNED_WORDS):
        violation_detected = True
        violation_reason = "استخدام كلمات ممنوعة"
        print(f"🔍 Offensive message detected from user {user_id} ({user.username or user.first_name})")
    
    if violation_detected:
        await message.delete()

        WARNINGS[user_id] = WARNINGS.get(user_id, 0) + 1
        warning_count = WARNINGS[user_id]

        print(f"📊 Warning count: {warning_count}/3 - Reason: {violation_reason}")

        if warning_count < 3:
            # إرسال تحذير للمستخدم
            if violation_reason == "إعادة توجيه رسالة من قناة":
                warning_text = f"⚠️ @{user.username or user.first_name} تم حذف رسالتك بسبب إعادة توجيه من قناة ({warning_count}/3). كررها وهتتمنع من الكلام!"
            else:
                warning_text = f"⚠️ @{user.username or user.first_name} تم حذف رسالتك بسبب مخالفة ({warning_count}/3). كررها وهتتمنع من الكلام!"
            
            await context.bot.send_message(
                chat_id=chat_id,
                text=warning_text
            )
            print(f"⚠️ Warning sent to user {user_id}")
        elif warning_count == 3:
            # كتم المستخدم لمدة 24 ساعة
            print(f"🚫 Attempting to mute user {user_id} for 24 hours...")
            
            try:
                # التحقق من أن المستخدم ليس مالك أو مدير المجموعة
                member = await context.bot.get_chat_member(chat_id, user_id)
                if member.status in ['creator', 'administrator']:
                    print(f"❌ Cannot mute user {user_id} - User is {member.status}")
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"⚠️ لا يمكن كتم @{user.username or user.first_name} لأنه مدير في المجموعة!"
                    )
                    WARNINGS[user_id] = 0  # إعادة تعيين العداد
                    return
                
                # كتم المستخدم العادي
                await context.bot.restrict_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    permissions=ChatPermissions(can_send_messages=False),
                    until_date=message.date + timedelta(hours=24)
                )
                
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"🚫 @{user.username or user.first_name} تم كتمه 24 ساعة بسبب 3 مخالفات متتالية."
                )
                
                print(f"✅ User {user_id} muted successfully for 24 hours")
                WARNINGS[user_id] = 0  # إعادة تعيين العداد بعد الكتم
                
            except Exception as e:
                print(f"❌ Error muting user {user_id}: {str(e)}")
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"⚠️ حدث خطأ أثناء محاولة كتم @{user.username or user.first_name}"
                )
                # عدم إعادة تعيين العداد في حالة الخطأ
    # رسالة عادية - لا توجد مخالفات

# تحميل الكلمات الممنوعة عند بداية التشغيل
load_banned_words()

# إعداد التطبيق
application = Application.builder().token(os.getenv("TELEGRAM_BOT_TOKEN")).build()

# إضافة معالجات الأوامر
application.add_handler(CommandHandler("start", start_command))
application.add_handler(CommandHandler("help", help_command))
application.add_handler(CommandHandler("addban", add_ban_command))
application.add_handler(CommandHandler("removeban", remove_ban_command))
application.add_handler(CommandHandler("listban", list_ban_command))
application.add_handler(CommandHandler("warnings", warnings_command))
application.add_handler(CommandHandler("clearwarnings", clear_warnings_command))

# إضافة معالج الترحيب بالأعضاء الجدد
application.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome_new_member))

# إضافة معالج جميع أنواع الرسائل (نص، صور، فيديو، إلخ)
application.add_handler(MessageHandler(~filters.COMMAND, handle_message))

# تشغيل البوت
application.run_polling()
